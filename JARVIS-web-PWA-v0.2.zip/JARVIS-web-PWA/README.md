# JARVIS Web/PWA v0.2

This package now includes a real backend layer instead of only a visual frontend.

## What is implemented

- Responsive installable PWA UI
- Browser speech-to-text where supported
- Browser speech synthesis for JARVIS replies
- Persistent conversation storage in SQLite
- Persistent long-term memory with a memory management screen
- Claude API orchestration on the server
- Claude tool use loop
- Web-search tool adapter
- Explicit memory-saving tool
- Confirmation records for consequential actions
- Backend health check
- Bearer-token protection when `JARVIS_API_TOKEN` is configured
- No provider API keys in the browser
- Clear offline and backend-error states

Anthropic's current documentation lists Claude Sonnet 5 as `claude-sonnet-5`, and the backend defaults to that model. citeturn0search4turn0search2

## Run backend

```bash
cd backend
python -m venv .venv
# activate the virtual environment
pip install -r requirements.txt
cp .env.example .env
# put your Anthropic API key and a strong JARVIS_API_TOKEN in .env
python run.py
```

Check `http://127.0.0.1:8000/health`.

## Run PWA

```bash
python3 -m http.server 8080 --directory web
```

Open the PWA at `http://127.0.0.1:8080` on the same computer. For an iPhone, deploy both pieces behind HTTPS and enter the public backend URL and JARVIS token under Settings.

## What is deliberately not enabled yet

The backend does not execute arbitrary shell commands, control another person's device, send messages, send email, spend money, delete arbitrary files, or change accounts. Those require explicit integrations and permission gates. The confirmation system is a foundation for adding those safely.

## Next engineering stage

1. Streaming responses and lower-latency voice
2. Proper search provider or Claude server-side web search
3. Calendar and reminders OAuth integrations
4. Email integration
5. Document/PDF/image ingestion
6. MCP client integration
7. Desktop companion for approved computer control
8. Scheduled jobs and push notifications
9. Stronger authentication, rate limiting, audit logs, and deployment configuration
10. Automated backend and browser tests
