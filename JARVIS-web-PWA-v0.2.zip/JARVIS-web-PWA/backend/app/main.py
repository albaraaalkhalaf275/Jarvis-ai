from __future__ import annotations

import json
import os
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any

import httpx
from bs4 import BeautifulSoup
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from anthropic import Anthropic

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("JARVIS_DB", str(BASE_DIR / "data" / "jarvis.db")))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
MODEL = os.getenv("JARVIS_MODEL", "claude-sonnet-5")
API_TOKEN = os.getenv("JARVIS_API_TOKEN", "")
CORS = [x.strip() for x in os.getenv("JARVIS_CORS_ORIGINS", "http://localhost:8080,http://127.0.0.1:8080").split(",") if x.strip()]

app = FastAPI(title="JARVIS Backend", version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=CORS, allow_credentials=False, allow_methods=["*"], allow_headers=["*"])


def db() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c


def init_db() -> None:
    with db() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                created_at REAL NOT NULL,
                title TEXT NOT NULL DEFAULT 'JARVIS Session'
            );
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at REAL NOT NULL,
                FOREIGN KEY(conversation_id) REFERENCES conversations(id)
            );
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                kind TEXT NOT NULL DEFAULT 'fact',
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS confirmations (
                id TEXT PRIMARY KEY,
                action TEXT NOT NULL,
                payload TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at REAL NOT NULL
            );
            """
        )


init_db()

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    conversation_id: str | None = None

class ChatResponse(BaseModel):
    response: str
    conversation_id: str
    tool_events: list[dict[str, Any]] = []

class MemoryRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2000)
    kind: str = "fact"

class ConfirmationDecision(BaseModel):
    approved: bool


def auth(authorization: str | None = Header(default=None)) -> None:
    if API_TOKEN and authorization != f"Bearer {API_TOKEN}":
        raise HTTPException(status_code=401, detail="Invalid JARVIS API token")


def conversation(cid: str | None) -> str:
    cid = cid or str(uuid.uuid4())
    with db() as c:
        row = c.execute("SELECT id FROM conversations WHERE id=?", (cid,)).fetchone()
        if not row:
            c.execute("INSERT INTO conversations(id,created_at) VALUES(?,?)", (cid, time.time()))
    return cid


def save_message(cid: str, role: str, content: str) -> None:
    with db() as c:
        c.execute("INSERT INTO messages(conversation_id,role,content,created_at) VALUES(?,?,?,?)", (cid, role, content, time.time()))


def recent_messages(cid: str, limit: int = 20) -> list[dict[str, str]]:
    with db() as c:
        rows = c.execute("SELECT role,content FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT ?", (cid, limit)).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


def memories(query: str = "", limit: int = 12) -> list[str]:
    with db() as c:
        if query:
            tokens = [t for t in query.lower().split() if len(t) > 2][:5]
            if tokens:
                where = " OR ".join("lower(text) LIKE ?" for _ in tokens)
                rows = c.execute(f"SELECT text FROM memories WHERE {where} ORDER BY id DESC LIMIT ?", tuple(f"%{t}%" for t in tokens) + (limit,)).fetchall()
            else:
                rows = []
        else:
            rows = c.execute("SELECT text FROM memories ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [r["text"] for r in rows]


def system_prompt(relevant: list[str]) -> str:
    mem = "\n".join(f"- {m}" for m in relevant) or "No saved memories are relevant."
    return f"""You are JARVIS, a personal AI assistant. Be concise, capable, honest, and action-oriented. Use tools when they materially improve the answer. Never claim an action happened unless the backend actually completed it. If an action would delete data, send a message/email, spend money, change an account, or otherwise have significant side effects, request confirmation instead of executing it.\n\nRelevant persistent memory:\n{mem}"""


def extract_text(resp: Any) -> str:
    parts: list[str] = []
    for block in getattr(resp, "content", []):
        if getattr(block, "type", None) == "text":
            parts.append(block.text)
    return "\n".join(parts).strip()


def web_search(query: str, max_results: int = 5) -> list[dict[str, str]]:
    # Lightweight search adapter. For production, replace with a dedicated search provider.
    url = "https://www.google.com/search"
    r = httpx.get(url, params={"q": query}, headers={"User-Agent": "Mozilla/5.0"}, timeout=10, follow_redirects=True)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    out = []
    for a in soup.select("a"):
        h = a.select_one("h3")
        href = a.get("href", "")
        if h and href.startswith("http"):
            out.append({"title": h.get_text(" ", strip=True), "url": href})
        if len(out) >= max_results:
            break
    return out


def make_confirmation(action: str, payload: dict[str, Any]) -> str:
    cid = str(uuid.uuid4())
    with db() as c:
        c.execute("INSERT INTO confirmations(id,action,payload,created_at) VALUES(?,?,?,?)", (cid, action, json.dumps(payload), time.time()))
    return cid


@app.get("/health")
def health() -> dict[str, Any]:
    return {"ok": True, "ai_configured": bool(os.getenv("ANTHROPIC_API_KEY")), "model": MODEL}

@app.get("/api/memories", dependencies=[Depends(auth)])
def get_memories() -> list[dict[str, Any]]:
    with db() as c:
        return [dict(r) for r in c.execute("SELECT id,text,kind,created_at FROM memories ORDER BY id DESC LIMIT 100")]

@app.post("/api/memories", dependencies=[Depends(auth)])
def add_memory(req: MemoryRequest) -> dict[str, Any]:
    with db() as c:
        cur = c.execute("INSERT INTO memories(text,kind,created_at) VALUES(?,?,?)", (req.text, req.kind, time.time()))
        return {"id": cur.lastrowid, "text": req.text, "kind": req.kind}

@app.delete("/api/memories/{memory_id}", dependencies=[Depends(auth)])
def delete_memory(memory_id: int) -> dict[str, bool]:
    with db() as c:
        c.execute("DELETE FROM memories WHERE id=?", (memory_id,))
    return {"deleted": True}

@app.get("/api/conversations/{cid}", dependencies=[Depends(auth)])
def get_conversation(cid: str) -> dict[str, Any]:
    return {"conversation_id": cid, "messages": recent_messages(cid, 100)}

@app.post("/api/chat", response_model=ChatResponse, dependencies=[Depends(auth)])
def chat(req: ChatRequest) -> ChatResponse:
    if not os.getenv("ANTHROPIC_API_KEY"):
        raise HTTPException(status_code=503, detail="ANTHROPIC_API_KEY is not configured")
    cid = conversation(req.conversation_id)
    save_message(cid, "user", req.message)
    history = recent_messages(cid, 24)
    relevant = memories(req.message)
    client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    tools = [
        {
            "name": "web_search",
            "description": "Search the public web for current information. Use when the user asks for current or externally verified information.",
            "input_schema": {"type": "object", "properties": {"query": {"type": "string"}, "max_results": {"type": "integer", "minimum": 1, "maximum": 5}}, "required": ["query"]},
        },
        {
            "name": "save_memory",
            "description": "Save a useful user fact or preference when the user explicitly asks you to remember it.",
            "input_schema": {"type": "object", "properties": {"text": {"type": "string"}, "kind": {"type": "string"}}, "required": ["text"]},
        },
        {
            "name": "request_confirmation",
            "description": "Create a confirmation request for a potentially consequential action. Do not perform the action.",
            "input_schema": {"type": "object", "properties": {"action": {"type": "string"}, "payload": {"type": "object"}}, "required": ["action", "payload"]},
        },
    ]
    events: list[dict[str, Any]] = []
    messages = history
    for _ in range(4):
        resp = client.messages.create(model=MODEL, max_tokens=1600, system=system_prompt(relevant), messages=messages, tools=tools)
        tool_uses = [b for b in resp.content if getattr(b, "type", None) == "tool_use"]
        if not tool_uses:
            answer = extract_text(resp) or "I completed the reasoning step but received no text response."
            save_message(cid, "assistant", answer)
            return ChatResponse(response=answer, conversation_id=cid, tool_events=events)
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for call in tool_uses:
            try:
                if call.name == "web_search":
                    result = web_search(call.input["query"], call.input.get("max_results", 5))
                elif call.name == "save_memory":
                    text_value = call.input["text"]
                    kind = call.input.get("kind", "fact")
                    with db() as c:
                        c.execute("INSERT INTO memories(text,kind,created_at) VALUES(?,?,?)", (text_value, kind, time.time()))
                    result = {"saved": True, "text": text_value}
                elif call.name == "request_confirmation":
                    confirmation_id = make_confirmation(call.input["action"], call.input["payload"])
                    result = {"confirmation_required": True, "confirmation_id": confirmation_id, "action": call.input["action"]}
                else:
                    result = {"error": "Unknown tool"}
            except Exception as exc:
                result = {"error": str(exc)}
            events.append({"tool": call.name, "result": result})
            results.append({"type": "tool_result", "tool_use_id": call.id, "content": json.dumps(result)})
        messages.append({"role": "user", "content": results})
    raise HTTPException(status_code=500, detail="JARVIS reached the tool-loop safety limit")

@app.get("/api/confirmations/{confirmation_id}", dependencies=[Depends(auth)])
def get_confirmation(confirmation_id: str) -> dict[str, Any]:
    with db() as c:
        r = c.execute("SELECT * FROM confirmations WHERE id=?", (confirmation_id,)).fetchone()
    if not r:
        raise HTTPException(status_code=404, detail="Confirmation not found")
    return {"id": r["id"], "action": r["action"], "payload": json.loads(r["payload"]), "status": r["status"]}

@app.post("/api/confirmations/{confirmation_id}", dependencies=[Depends(auth)])
def decide_confirmation(confirmation_id: str, decision: ConfirmationDecision) -> dict[str, Any]:
    status = "approved" if decision.approved else "rejected"
    with db() as c:
        cur = c.execute("UPDATE confirmations SET status=? WHERE id=? AND status='pending'", (status, confirmation_id))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Pending confirmation not found")
    return {"id": confirmation_id, "status": status}
