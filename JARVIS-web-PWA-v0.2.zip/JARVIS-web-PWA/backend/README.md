# JARVIS Backend

This is the real AI layer for the PWA. It keeps Anthropic credentials server-side, stores conversation history and memories in SQLite, supports Claude tool use, web search, memory saving, and confirmation records.

## Setup

1. Install Python 3.11+.
2. `cd backend`
3. `python -m venv .venv`
4. Activate the environment.
5. `pip install -r requirements.txt`
6. Copy `.env.example` to `.env`.
7. Add your Anthropic API key and change `JARVIS_API_TOKEN`.
8. Run `python run.py`.
9. Open `http://127.0.0.1:8000/health`.

## Connect the PWA

Serve the `web` directory with HTTPS when using an iPhone. In the PWA, tap Connect and enter the public backend URL. If `JARVIS_API_TOKEN` is set, the PWA sends it as a Bearer token.

## Important

The backend intentionally does not expose arbitrary shell execution, unrestricted file deletion, email sending, payments, or account control. Those require dedicated integrations and permission checks. A confirmation record is created first for consequential actions.
